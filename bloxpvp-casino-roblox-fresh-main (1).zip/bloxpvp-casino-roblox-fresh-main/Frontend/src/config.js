/** @format */

export const production = false;

export default {
  api: production ? "https://api.bloxpvp.com" : "https://323e38b2-4f53-42ed-a232-ad2bc264e8c2-00-3c2u3risany1k.picard.replit.dev",
  h_captcha_key: production
    ? "495be111-f6a7-4ca5-9b8f-d0149998a742"
    : "20000000-ffff-ffff-ffff-000000000002",
};

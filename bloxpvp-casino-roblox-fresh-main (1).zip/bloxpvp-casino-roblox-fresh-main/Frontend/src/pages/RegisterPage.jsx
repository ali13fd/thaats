import Register from "../components/Account/Register";
import "./AuthPage.css"

export default function RegisterPage() {
    return (
        <div>
            <Register></Register>
        </div>
    );
}

import Login from "../components/Account/Login";
import "./AuthPage.css"

export default function LoginPage() {
    return (
        <div>
            <Login></Login>
        </div>
    );
}
